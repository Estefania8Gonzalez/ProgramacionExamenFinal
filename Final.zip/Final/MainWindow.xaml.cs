﻿using Final.Clases;
using Final.Conexion;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Final
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        CConexion cDB = new CConexion();

        ObservableCollection<Empleado> ListaEmpleado;
        ObservableCollection<Departamento> ListaDepartamento;
        public MainWindow()
        {
            ListaEmpleado = new ObservableCollection<Empleado>();
            ListaDepartamento = new ObservableCollection<Departamento>();

            InitializeComponent();
            //IniData();
        }


        private void btnguardar_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult r = MessageBox.Show("¿Está seguro de guardar?", "Atención", MessageBoxButton.OKCancel);
            if (MessageBoxResult.OK == r)
            {
                cDB.ExecuteSql("INSERT INTO empleados (id, nombre, apellido) VALUES ('" + Id.Text + "', '" + Nombre.Text + "', '" + Apellido.Text + "')");

                LoadEmpleado();
                clearEmpleado();
            }
        }

        private void InitData()
        {
            LoadEmpleado();
            clearEmpleado();
        }

        private void clearEmpleado()
        {
            Id.Text = "";
            Nombre.Text = "";
            Apellido.Text = "";
        }

        private void LoadEmpleado()
        {
            ListaEmpleado.Clear();
            MySqlDataReader Reader = cDB.ListaSql("SELECT id, nombre, apellido FROM empleados");

            if (Reader != null)
            {
                while (Reader.Read())
                {
                    Empleado p = new Empleado();

                    p.Id = Reader.GetValue(0).ToString();
                    p.Nombre = Reader.GetValue(1).ToString();
                    p.Apellido = Reader.GetValue(2).ToString();
                    ListaEmpleado.Add(p);
                }
            }
        }

        private void btneliminar_Click(object sender, RoutedEventArgs e)
        {
            if (dgTablaEmpleado.SelectedItem != null)
            {
                Empleado empleadoSeleccionado = (Empleado)dgTablaEmpleado.SelectedItem;
                string idEmpleado = empleadoSeleccionado.Id;

                MessageBoxResult r = MessageBox.Show($"¿Está seguro de eliminar al empleado con ID {idEmpleado}?", "Atención", MessageBoxButton.OKCancel);
                if (MessageBoxResult.OK == r)
                {
                    cDB.ExecuteSql($"DELETE FROM empleados WHERE id = '{idEmpleado}'");
                    cargarEmpleado();
                    eliminarEmpleado();
                }
            }
            else
            {
                MessageBox.Show("Seleccione un empleado para eliminar.", "Atención");
            }
        }

        private void IniiitData()
        {
            cargarEmpleado();
            eliminarEmpleado();
        }

        private void cargarEmpleado()
        {
            Id.Text = "";
            Nombre.Text = "";
            Apellido.Text = "";
        }

        private void eliminarEmpleado()
        {
            ListaEmpleado.Clear();
            MySqlDataReader Reader = cDB.ListaSql("SELECT id, nombre, apellido FROM empleados");

            while (Reader.Read())
            {
                Empleado p = new Empleado();

                p.Id = Reader.GetValue(0).ToString();
                p.Nombre = Reader.GetValue(1).ToString();
                p.Apellido = Reader.GetValue(2).ToString();
                ListaEmpleado.Add(p);
            }
        }

        private void btnModificar_Click(object sender, RoutedEventArgs e)
        {
            if (dgTablaEmpleado.SelectedItem != null)
            {
                Empleado empleadoSeleccionado = (Empleado)dgTablaEmpleado.SelectedItem;
                string idEmpleado = empleadoSeleccionado.Id;

                MessageBoxResult r = MessageBox.Show($"¿Está seguro de modificar al empleado con ID {idEmpleado}?", "Atención", MessageBoxButton.OKCancel);
                if (MessageBoxResult.OK == r)
                {
                    cDB.ExecuteSql($"UPDATE empleados SET nombre = '{Nombre.Text}', apellido = '{Apellido.Text}' WHERE id = '{idEmpleado}'");
                    cargandoEmpleado();
                    modificarEmpleado();
                }
            }
            else
            {
                MessageBox.Show("Seleccione un empleado para modificar.", "Atención");
            }
        }

        private void IniciaData()
        {
            cargandoEmpleado();
            modificarEmpleado();
        }

        private void cargandoEmpleado()
        {
            Id.Text = "";
            Nombre.Text = "";
            Apellido.Text = "";
        }

        private void modificarEmpleado()
        {
            ListaEmpleado.Clear();
            MySqlDataReader Reader = cDB.ListaSql("SELECT id, nombre, apellido FROM empleados");

            while (Reader.Read())
            {
                Empleado p = new Empleado();

                p.Id = Reader.GetValue(0).ToString();
                p.Nombre = Reader.GetValue(1).ToString();
                p.Apellido = Reader.GetValue(2).ToString();
                ListaEmpleado.Add(p);
            }
        }

        private void btnagregar_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnGuardar_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBoxResult r = MessageBox.Show("¿Está seguro de guardar?", "Atención", MessageBoxButton.OKCancel);
            if (MessageBoxResult.OK == r)
            {
                cDB.ExecuteSql("INSERT INTO empleados (destino, nombre, documento) VALUES ('" + destino1.Text + "', '" + nombre1.Text + "', '" + documento1.Text + "')");

                LoadDepartamento();
                clearDepartamento();
            }
        }

        private void IncioData()
        {
            LoadDepartamento();
            clearDepartamento();
        }

        private void clearDepartamento()
        {
            destino1.Text = "";
            nombre1.Text = "";
            documento1.Text = "";
        }

        private void LoadDepartamento()
        {
            ListaEmpleado.Clear();
            MySqlDataReader Reader = cDB.ListaSql("SELECT destino, nome, documento FROM empleador");

            if (Reader != null)
            {
                while (Reader.Read())
                {
                    Empleado p = new Empleado();

                    p.Id = Reader.GetValue(0).ToString();
                    p.Nombre = Reader.GetValue(1).ToString();
                    p.Apellido = Reader.GetValue(2).ToString();
                    ListaEmpleado.Add(p);
                }
            }
        }

        private void btnEliminar_Click_1(object sender, RoutedEventArgs e)
        {
            ListaDepartamento.Clear();
            MySqlDataReader Reader = cDB.ListaSql("SELECT destino, nome, documento FROM empleados");

            while (Reader.Read())
            {
                Departamento q = new Departamento();

                q.Destino = Reader.GetValue(0).ToString();
                q.Nombre = Reader.GetValue(1).ToString();
                q.Documento = Reader.GetValue(2).ToString();
                ListaDepartamento.Add(q);
            }
        }

        private void btnModificarD_Click(object sender, RoutedEventArgs e)
        {
            if (dgTablaDepartamento.SelectedItem != null)
            {
                Departamento departamentoSeleccionado = (Departamento)dgTablaDepartamento.SelectedItem;
                string destinodepartamento = departamentoSeleccionado.Destino;

                MessageBoxResult r = MessageBox.Show($"¿Está seguro de modificar al departamento con destino a {destinodepartamento}?", "Atención", MessageBoxButton.OKCancel);
                if (MessageBoxResult.OK == r)
                {
                    cDB.ExecuteSql($"UPDATE departamento SET nombre = '{nombre1.Text}', documento = '{documento1.Text}' WHERE id = '{destinodepartamento}'");
                    cargandoDepartamento();
                    modificarDepartamento();
                }
            }
            else
            {
                MessageBox.Show("Seleccione un depaartamento para modificar.", "Atención");
            }
        }

        private void InicialData()
        {
            cargandoDepartamento();
            modificarDepartamento();
        }

        private void cargandoDepartamento()
        {
            destino1.Text = "";
            nombre1.Text = "";
            documento1.Text = "";
        }

        private void modificarDepartamento()
        {
            ListaDepartamento.Clear();
            MySqlDataReader Reader = cDB.ListaSql("SELECT destino, nome, documento FROM empleador");

            while (Reader.Read())
            {
                Departamento q = new Departamento();

                q.Destino = Reader.GetValue(0).ToString();
                q.Nombre = Reader.GetValue(1).ToString();
                q.Documento = Reader.GetValue(2).ToString();
                ListaDepartamento.Add(q);
            }
        }

        private void btnagregarD_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
