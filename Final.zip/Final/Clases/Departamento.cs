﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Clases
{
    internal class Departamento
    {
        private string destino;
        private string nombre;
        private string documento;

        public string Destino { get => destino; set => destino = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Documento { get => documento; set => documento=value; }
    }
}
