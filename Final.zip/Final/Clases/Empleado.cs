﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Clases
{
    internal class Empleado
    {
        private string id;
        private string nombre;
        private string apellido;
        private string trabajo;
        private string salario;
        private string comision;

        public string Id { get => id; set => id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Trabajo { get => trabajo; set => trabajo = value; }
        public string Salario { get => salario; set => salario = value; }
        public string Comision { get => comision; set => comision=value; }
        public string Apellido { get => apellido; set => apellido=value; }
    }
}
