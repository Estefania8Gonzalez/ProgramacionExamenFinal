﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Conexion
{
    internal class CConexion
    {
        MySqlConnectionStringBuilder csb = new MySqlConnectionStringBuilder();

        public CConexion()
        {
            this.initConfig();
        }

        private void initConfig()
        {
            csb.Server = "localhost";
            csb.Database = "empleador";
            csb.UserID = "root";
            csb.Password = "root";

        }

        public void ExecuteSql(string sql)
        {
            MySqlConnection conn = new MySqlConnection(csb.ToString());
            try
            {
                MySqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = sql;
                conn.Open();
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message, "Error");
            }

            finally
            {
                conn.Close();
            }
        }


        public MySqlDataReader ListaSql(string sql)
        {
            MySqlDataReader MySqlDataReader = null;
            MySqlConnection conn = new MySqlConnection(csb.ToString());

            try
            {
                conn.Open();
                MySqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = sql;

                MySqlDataReader = cmd.ExecuteReader();
            }
            catch (SystemException ex)
            {
                System.Windows.MessageBox.Show(ex.Message, "Error");
            }
            finally
            {
                conn.Close(); 
            }

            return MySqlDataReader;
        }
    }
}
